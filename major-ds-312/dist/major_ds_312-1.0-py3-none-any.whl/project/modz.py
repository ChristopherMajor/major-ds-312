def enlarge(n):
    return n * 100

# x = int(input("Input number:"))
# result = enlarge(x)
# print(result)

if __name__ =="__main__":
    
    x = int(input("Input number:"))
    result = enlarge(x)
    print(result)
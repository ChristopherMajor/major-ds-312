import pandas
from project.modz import enlarge

print("uWu")

df = pandas.DataFrame({'state': ['CT', "CO", "CA","TX"]})
print(df.head())

print(enlarge(9))